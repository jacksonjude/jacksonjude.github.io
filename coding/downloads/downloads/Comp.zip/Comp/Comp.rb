# Version = 1.0
# /\ /\ /\ /\ /\
# Version Goes Here
# The JC Comp
# © 2017 JC inc.
# DO NOT DISTRIBUTE

$VERBOSE = nil

require 'fileutils'
require 'rational'
require 'mathn'
require 'etc'
require 'io/console'
require 'encrypted_strings'

class TeeIO < IO

  def initialize orig, file
    @orig = orig
    @file = file
    @log = ""
  end

  def write string
    @file.write string
    @orig.write string
    @log = @log + "\n" + string
  end

  def logReturn
  	return @log
  end

end

a = true
if a

macUsername = File.expand_path("~")

#Testing if account is saved on disk
doesIt = File.exists?(macUsername + '/Desktop/Comp/')
doesIts = doesIt.to_s

if !doesIt
    FileUtils.mkdir(macUsername + "/Desktop/Comp")
    FileUtils.mkdir(macUsername + "/Desktop/Comp/logs")
end
tee = TeeIO.new $stdout, File.new(macUsername + "/Desktop/Comp/logs/log-" + Time.new.to_s + ".log", 'w')

begin

#Starting Intro Credits
development = 0
if File.exists?(macUsername + '/Desktop/Comp/development.txt')
	filename = macUsername + "/Desktop/Comp/development.txt"
	File.open filename, 'r' do |f|
		lines = Array.new
		f.each_line do |line|
			lines.push line
		end

		if lines[0] == "true"
			development = 1
		elsif lines[1] == "true"
			development = 2
		else
			development = 0
		end
	end
end

puts development

system('clear')

if development == 0
	sleep 1
	puts "J"
	sleep 0.7
	puts "C"
	sleep 0.9
	puts
	sleep 0.4
	puts "Version 1.0 Alpha"
	sleep 0.4
	puts
	sleep 1
	system('clear')
	sleep 0.3

	puts "L "
	sleep 0.1
	system('clear')
	puts "L O\nO "
	sleep 0.1
	system('clear')
	puts "L O A \nO A\nA D"
	sleep 0.1
	system('clear')
	puts "L O A D \nO A D\nA D I\nD I N"
	sleep 0.1
	system('clear')
	puts "L O A D I \nO A D I\nA D I N\nD I N\nI N"
	sleep 0.1
	system('clear')
	puts "L O A D I N \nO A D I N\nA D I N\nD I N\nI N\nN"
	sleep 0.1

	system('clear')
	puts "L O A D I N G \nO A D I N\nA D I N\nD I N\nI N\nN"
	sleep 0.1
	system('clear')
	puts "L O A D I N G \nO A D I N G\nA D I N\nD I N\nI N\nN"
	sleep 0.1
	system('clear')
	puts "L O A D I N G \nO A D I N G\nA D I N G\nD I N\nI N\nN"
	sleep 0.1
	system('clear')
	puts "L O A D I N G \nO A D I N G\nA D I N G\nD I N G\nI N\nN"
	sleep 0.1
	system('clear')
	puts "L O A D I N G \nO A D I N G\nA D I N G\nD I N G\nI N G\nN"
	sleep 0.1
	system('clear')
	puts "L O A D I N G \nO A D I N G\nA D I N G\nD I N G\nI N G\nN G"
	sleep 0.1
	system('clear')
	puts "L O A D I N G \nO A D I N G\nA D I N G\nD I N G\nI N G\nN G\nG"
	sleep 0.1

	system('clear')
	puts "L O A D I N G \nO A D I N G N\nA D I N G N\nD I N G N\nI N G N\nN G N\nG N"
	sleep 0.1
	system('clear')
	puts "L O A D I N G \nO A D I N G N\nA D I N G N I\nD I N G N I\nI N G N I\nN G N I\nG N I"
	sleep 0.1
	system('clear')
	puts "L O A D I N G \nO A D I N G N\nA D I N G N I\nD I N G N I D\nI N G N I D\nN G N I D\nG N I D"
	sleep 0.1
	system('clear')
	puts "L O A D I N G \nO A D I N G N\nA D I N G N I\nD I N G N I D\nI N G N I D A\nN G N I D A\nG N I D A"
	sleep 0.1
	system('clear')
	puts "L O A D I N G \nO A D I N G N\nA D I N G N I\nD I N G N I D\nI N G N I D A\nN G N I D A O\nG N I D A O"
	sleep 0.1
	system('clear')
	puts "L O A D I N G \nO A D I N G N\nA D I N G N I\nD I N G N I D\nI N G N I D A\nN G N I D A O\nG N I D A O L"
	sleep 1.5
elsif development == 1
	puts "Development Mode: On"
    sleep 0.2
    puts "Skipping Title..."
    sleep 0.2
end

if development != 2
	puts "\nAccount saved: " + doesIts
	sleep 0.5
end

time = Time.new
times = time.to_s

if doesIt == false
	#Making all necessary files
    system('curl -s -O https://dl.dropboxusercontent.com/s/lioiymdv4swc83d/ST.txt?dl=1')
	FileUtils.mv(macUsername + '/Desktop/ST.txt?dl=1', macUsername + '/Desktop/Comp/ST.txt')

	filename2 = "development.txt"
	File.open filename2, 'w' do |f|
		f.write "false"
	end
	FileUtils.mv(macUsername + '/Desktop/development.txt', macUsername + '/Desktop/Comp/development.txt')

	puts "Welcome to your computer! " + "What would you like your username to be?"
	aUser = gets.chomp
	sleep 0.5
	puts "\nWelcome, " + aUser

	filename = "aUser.txt"
	File.open filename, 'w' do |f|
				f.write aUser
			end
	FileUtils.mv(macUsername + '/Desktop/aUser.txt', macUsername + '/Desktop/Comp/aUser.txt')
	loop = 1

	while loop == 1
		puts "\nType your password"
		password = STDIN.noecho(&:gets).chomp
		puts "\nRetype your password"
		password2 = STDIN.noecho(&:gets).chomp

		if password2 == password
			puts "\nCorrect"

            ecryptedString = "yghabt".encrypt(:symmetric, :algorithm => 'des-ecb', :password => password)

			filename = "Password.txt"
				File.open filename, 'w' do |f|
					f.write ecryptedString
				end
		    loop = 0
		    puts "Please Restart"
		else
			puts "\nTry again"
		end
	end
    FileUtils.mkdir(macUsername + '/Desktop/Comp/Password')
    FileUtils.mv(macUsername + '/Desktop/Password.txt', macUsername + '/Desktop/Comp/Password/Password.txt')
    system('chmod 0 ~/Desktop/Comp/Password')
elsif doesIt == true
	#Starting to Log Output of Console
	if development != 2
		puts "Begining to Log Output...\n"
		$stdout = tee
	end

	filename = macUsername + '/Desktop/Comp/aUser.txt'
	File.open filename, 'r' do |f|
		aUser = f.read
	end
	if development != 2
		puts "Welcome " + aUser
	end

	filename = macUsername + '/Desktop/Comp/Password/Password.txt'
	$stdout = STDOUT
	system('chmod 755 ~/Desktop/Comp/Password')
		File.open filename, 'r' do |f|
			password = f.read
		end
	system('chmod 0 ~/Desktop/Comp/Password')
	$stdout = tee

	loop = 1
	while loop == 1

		puts "Type your password"
		password2 = STDIN.noecho(&:gets).chomp

		passcmd = password2.include?("^")
		passcmd2 = password2.downcase.sub!("^", "")

		if passcmd == true && passcmd2 == "r"
			puts "Activating Rescue Mode..."
			sleep 0.5

			puts "Please type the last 3 or first 3 digits of your passcode"
			pass = STDIN.noecho(&:gets).chomp

			pass1 = password.include?(pass)

			if pass1 == true
				puts "Change your passcode:"
				new = gets.chomp

				system('chmod 755 ~/Desktop/Comp/Password')

				FileUtils.rm(macUsername + '/Desktop/Comp/Password/Password.txt')
				filename = "Password.txt"
				File.open filename, 'w' do |f|
					f.write new
				end
				FileUtils.mv(macUsername + '/Desktop/Password.txt', macUsername + '/Desktop/Comp/Password/Password.txt')
				system('chmod 0 ~/Desktop/Comp/Password')

				puts "Please Restart"
				loop = 0
				break
			else
				puts "Incorrect"
			end
		end

		if password.decrypt(:symmetric, :algorithm => 'des-ecb', :password => password2) == 'yghabt'
			puts "login success"
			loop = 0
		end
		if password == ""
			puts "	Comp - ERROR102:PASSWORD NOT FOUND"
			puts "	DEV: password = " + password
		end
	end

	loop = 1

	runOnce = 0

	while loop == 1

		#Birthday and April Fools
		bdayExists = File.exists?(macUsername + '/Desktop/Comp/Bday.txt')

		if bdayExists
			filename = macUsername + '/Desktop/Comp/Bday.txt'
			File.open filename, 'r' do |f|
                bdayLines = Array.new
                f.each_line do |line|
            		bdayLines.push(line)
            	end

			    bdayDay = bdayLines[1]
                bdayMonth = bdayLines[0]

	            time = Time.new
	            tm = time.month.to_i
	            td = time.day.to_i

	            if bdayMonth == tm && bdayDay == td
		            sleep 0.5
		            puts "HAPPY BIRTHDAY!!!"
		            sleep 1
	            end
		    end
		end

		time = Time.new
		tm = time.month.to_i
		td = time.day.to_i

		if tm == 4 && td == 1
			puts
			sleep 1
			puts "YOU WON $1,000,000,000!"
			sleep 3
			puts "APRIL FOOLS!\n"
			sleep 3
		end

		loopST = 1
		while loopST == 1
			#Splash Text, Main Title Screen
			filename = macUsername + '/Desktop/Comp/ST.txt'
			File.open filename, 'r' do |f|
				lines = Array.new
				f.each_line do |line|
					lines.push line
				end

				SC = rand(lines.count + 1)

				ST = lines[SC]

				if not ST.to_s == ""
					puts "Choose what you would like to do:"
					puts "Settings/Customize (S), Off (O), How many days old (DO), Your Birthday (B), Movie (M), Calculator (C), Version/Credits (V), Text (T), Plugins (P) " + ST.to_s
					loopST = 0
				end
			end
		end

		if runOnce == 0
			$stdout.puts 'Launched Sucessfully, Shutting Down Log...'
			$stdout = STDOUT
			runOnce = 1
		end

		aChoice = gets.chomp

		if aChoice.upcase == "DO"
			puts "Loading..."
			sleep 0.1
			time = Time.new

			puts "How old are you?"
			y = gets.chomp.to_i

			puts "what month is your birthday? (#)"
			m = gets.chomp.to_i

			puts "What day of the month is your birthday? (#)"
			d = gets.chomp.to_i

			puts "Prosessing..."
			sleep 1

			yd = y * 365

			aTimed = time.day.to_i

			if aTimed > d
				days = aTimed - d
			else
				days = d - aTimed
			end

			aTimem = time.month.to_i

			if aTimem > m
				months = aTimem - m
			else
				months = m - aTimem
			end

			md = months * 31

			ly = y / 4

			o = md + yd + d + ly.floor

			os = o.to_s

			puts "You are " + os + " days old"

			sleep 1
		end

		if aChoice.upcase == "O"
			loopsd = 1
			while loopsd == 1
				puts "SD, Sleep, Reboot, Back"
				aChoice4 = gets.chomp.upcase
				if aChoice4 == "REBOOT"
					system('cd ' + macUsername + '/Desktop')
					system('ruby Comp.rb')
					loop = 0
					loopsd = 0
				elsif aChoice4 == "SD"
					sleep 0.5
					loop = 0
					puts "logout"
					sleep 0.5
					loopsd = 0
				elsif aChoice4 == "SLEEP"
					loopSleep = 1
					begin loopSleep == 1
						system('clear')
						puts "Z"
						sleep 1
						system('clear')
						puts "ZZ"
						sleep 1
						system('clear')
						puts "ZZZ"
						a = gets.chomp
					end while a == "\n"
				elsif aChoice4 == "BACK"
					loopsd = 0
				end
			end
		end

		if aChoice.upcase == "C"
			loopc = 1

			while loopc == 1

				puts "Choose what to do:"
				puts "Standard Operations (S), Just Fractions (F), Simplifying Fracions (SF), Memory add (ma), stop"

				c = gets.chomp.upcase

				if c == "MA"
					puts "Type new memory"
					m = gets.chomp

					filename = macUsername + '/Desktop/Comp/m.txt'
							File.open filename, 'w' do |f|
								f.write m
							end

					puts "Memory added"

				end

				if c == "STOP"
					loopc = 0
				end

				if c == "S"

					puts "Type in a number or mr"

					num1s = gets.chomp

					if num1s == "mr"
						filename = macUsername + '/Desktop/Comp/m.txt'
							File.open filename, 'r' do |f|
								num1s = f.read
							end
					end

					tf1 = num1s.include?(".")

					if tf1 == false

						num1i = num1s.to_f

						num1 = num1i * 1.00

					else

						num1i = num1s.to_f

						num1 = num1i

					end



					puts "Type a operation (+, -, *, /)"

					oP = gets.chomp

					puts "Type a 2nd number or mr"

					num2s = gets.chomp

					if num2s == "mr"
						filename = macUsername + '/Desktop/Comp/m.txt'
							File.open filename, 'r' do |f|
								num2s = f.read
							end
					end

					tf2 = num2s.include?(".")

					if tf2 == false

						num2i = num2s.to_f

						num2 = num2i * 1.00

					else

						num2i = num2s.to_f

						num2 = num2i

					end

					if oP == "+"
						a = num1 + num2

					elsif oP == "-"
						a = num1 - num2

					elsif oP == "*"
						a = num1 * num2

					elsif oP == "/"
						a = num1 / num2

					else
						a = "ERROR: CANT DEFINE oP" +
						"DEV: oP: " + oP
					end

					puts "\nLoading..."

					as = a.to_s

					tf3 = as.include?(".0")

					if tf3 == true

						as.sub! '.0', ''

					end

					sleep 0.2

					puts "\nYour answer is:"
					sleep 0.5
					puts as
					sleep 1
					puts "stop, memory add (ma)"

					s = gets.chomp

					if s == "stop"
						loopc = 0
					elsif s == "ma"
						filename = macUsername + '/Desktop/Comp/m.txt'
							File.open filename, 'w' do |f|
								f.write as
							end
					end
				elsif c == "F"

					puts "Type in the numerator for the first fraction or mr"
					n1s = gets.chomp
					if n1s == "mr"
						filename = macUsername + '/Desktop/Comp/m.txt'
							File.open filename, 'r' do |f|
								n1s = f.read
							end
					end
					n1 = n1s.to_i

					puts "Type in the denomonator for the first fraction or mr"
					d1s = gets.chomp
					if d1s == "mr"
						filename = macUsername + '/Desktop/Comp/m.txt'
							File.open filename, 'r' do |f|
								d1s = f.read
							end
					end
					d1 = d1s.to_i

					puts "Type a operation (+, -, *, /)"

					oPf = gets.chomp

					puts "Type in the numerator for the second fraction or mr"
					n2s = gets.chomp
					if n2s == "mr"
						filename = macUsername + '/Desktop/Comp/m.txt'
							File.open filename, 'r' do |f|
								n2s = f.read
							end
					end
					n2 = n2s.to_i

					puts "Type in the denomonator for the second fraction or mr"
					d2s = gets.chomp
					if d2s == "mr"
						filename = macUsername + '/Desktop/Comp/m.txt'
							File.open filename, 'r' do |f|
								d2s = f.read
							end
					end
					d2 = d2s.to_i

					if oPf == "+"
						af = Rational(n1, d1) + Rational(n2, d2)

					elsif oPf == "-"
						af = Rational(n1, d1) - Rational(n2, d2)

					elsif oPf == "*"
						af = Rational(n1, d1) * Rational(n2, d2)

					elsif oPf == "/"
						af = Rational(n1, d1) / Rational(n2, d2)

					else
						af = "ERROR: CANT DEFINE oPf" +
						" DEV: oP: " + oPf
					end

					puts "\nLoading..."

					afs = af.to_s

					sleep 0.2

					puts "\nYour answer is:"
					sleep 0.5
					puts afs
					sleep 1

					puts "Type stop to stop"

					s = gets.chomp

					if s == "stop"
						loopc = 0
					end

				end

				if c == "SF"

					puts "Type the numerator or mr"
					ns = gets.chomp
					if ns == "mr"
						filename = macUsername + '/Desktop/Comp/m.txt'
							File.open filename, 'r' do |f|
								ns = f.read
							end
					end
					n = ns.to_i

					puts "Type the denominator or mr"
					gs = gets.chomp
					if gs == "mr"
						filename = macUsername + '/Desktop/Comp/m.txt'
							File.open filename, 'r' do |f|
								gs = f.read
							end
					end
					g = gs.to_i

					sf = n/g

					puts "\nYour answer is:"
					sleep 0.5
					puts sf
					sleep 1

					puts "Type stop to stop"

					s = gets.chomp

					if s == "stop"
						loopc = 0
					end
				end
			end
		end

		if aChoice.upcase == "M"
			loopm = 1
			while loopm == 1

				aM = File.directory?(macUsername + '/Desktop/Comp/Movie/')

				if aM == true

					puts "What movie would you like to play? or stop"
					filename = macUsername + '/Desktop/Comp/Movie/Movies.txt'
					File.open filename, 'r' do |f|
						aMovies = f.read.to_s

						puts aMovies + "\nnew\nstop"
					end

					aChoiceM = gets.chomp.upcase

					if aChoiceM == "EXAMPLE"
						system ("clear")
						puts "JC productions"
						sleep 2
						system ("clear")
						puts "presents..."
						sleep 2
						system ("clear")
						loopa = 1
						loopas = 10
						while loopa <= loopas
							puts "1234567890	WIP"
							sleep 0.1
							system ("clear")
							puts "!@#$\%^&*()	WIP"
							sleep 0.1
							system ("clear")
							loopa = loopa + 1
						end

					elsif aChoiceM == "NEW"
						loopnm1 = 1
						while loopnm1 == 1
							puts "\nWARNING: CREATING THIS WILL OVERWRITE ANY PREVIOUS MOVIE"
							puts "Which kind would you like to make"
							puts "One line frame (O), Full page frame (F), stop"
							aChoicenm = gets.chomp.upcase

							if aChoicenm == "O"
								puts "how many frames? (1 - 4)"
								fr = gets.chomp
								puts "how many times do you want to loop?"
								ln = gets.chomp.to_i
								l = ln - 1
								puts "how many seconds to sleep between each frame? (decimal)"
								s = gets.chomp
								puts "make one frame"
								f1 = gets.chomp
								if fr >= "2"
									puts "make the 2nd frame"
									f2 = gets.chomp
								end
								if fr >= "3"
									puts "make the 3rd frame"
									f3 = gets.chomp
								end
								if fr == "4"
									puts "make the 4th frame"
									f4 = gets.chomp
								end
								filename = "Movie1.txt"
								File.open filename, 'w' do |f|
									f.write fr
									f.write "\n"
									f.write l
									f.write "\n"
									f.write s
									f.write "\n"
									f.write f1
									if fr >= "2"
										f.write "\n"
										f.write f2
									end
									if fr >= "3"
										f.write "\n"
										f.write f3
									end
									if fr == "4"
										f.write "\n"
										f.write f4
									end
								end
								me = File.exists?(macUsername + '/Desktop/Comp/Movie/Movie1')
								if me == false
									FileUtils.mkdir(macUsername + '/Desktop/Comp/Movie/Movie1/')
								end
								FileUtils.mv(macUsername + '/Desktop/Movie1.txt', macUsername + '/Desktop/Comp/Movie/Movie1/Movie1.txt')

								filename = macUsername + '/Desktop/Comp/Movie/Movies.txt'
								File.open filename, 'r' do |f|
									aMovies = f.read

								filename = macUsername + '/Desktop/Comp/Movie/Movies.txt'
								File.open filename, 'w' do |f|
									aMoviei = aMovies.include?('M1')
									if aMoviei == true
										f.write aMovies.sub!("M1", "") + "M1"
									else
										f.write aMovies + "M1" + "\n"
									end
								end
								end
							end
							if aChoicenm == "F"
								me = File.exists?(macUsername + '/Desktop/Comp/Movie/Movie2')
								if me == false
									FileUtils.mkdir(macUsername + '/Desktop/Comp/Movie/Movie2/')
								end
								puts "How many frames (1 - 4)"
								fr = gets.chomp
								puts "How many times to loop"
								l = gets.chomp
								puts "How long do you want it to pause between each frame in seconds (decimal)"
								s = gets.chomp
								filename = "Movie2.txt"
								File.open filename, 'w' do |f|
									f.write fr
									f.write "\n"
									f.write l
									f.write "\n"
									f.write s
									FileUtils.mv(macUsername + '/Desktop/Movie2.txt', macUsername + '/Desktop/Comp/Movie/Movie2/Movie2.txt')
									me2 = File.exists?(macUsername + '/Desktop/Comp/Movie/Movie2')
									if me2 == false
									FileUtils.mkdir(macUsername + '/Desktop/Comp/Movie/Movie2/')
									end
								end
								filename = macUsername + '/Desktop/Comp/Movie/Movies.txt'
								File.open filename, 'r' do |f|
									aMovies2 = f.read

								filename = macUsername + '/Desktop/Comp/Movie/Movies.txt'
								File.open filename, 'w' do |f|
									aMoviei2 = aMovies2.include?('M2')
									if aMoviei2 == true
										f.write aMovies2.sub!("M2", "") + "M2"
									else
										f.write aMovies2 + "M2" + "\n"
									end
								end
								end
								puts "Now, you have to make files x - 80 characters and y - 24 lines. Place them in /Comp/Movie/Movie2/f1.txt (f1.txt for frame one and f2.txt for frame two, etc)"
							end
							if aChoicenm == "stop"
								loopnm1 = 0
							end
						end
					elsif aChoiceM == "M1"
						aMovie1 = File.exists?(macUsername + '/Desktop/Comp/Movie/Movie1/Movie1.txt')
						if aMovie1 == true
							File.open(macUsername + '/Desktop/Comp/Movie/Movie1/Movie1.txt') do |file|
								lines = Array.new
								file.each_line do |line|
									lines.push line
								end
								aM10 = lines[0].to_i
								aM11 = lines[1].to_i
								aM12 = lines[2].to_f
								aM13 = lines[3]
								aM14 = lines[4]
								aM15 = lines[5]
								aM16 = lines[6]

								lm = aM11
								lmn = 0
								while lm >= lmn
									system ("clear")
									if aM10 >= 1
										puts aM13
										sleep aM12
									end
									system ("clear")
									if aM10 >= 2
										puts aM14
										sleep aM12
									end
									system ("clear")
									if aM10 >= 3
										puts aM15
										sleep aM12
									end
									system ("clear")
									if aM10 == 4
										puts aM16
										sleep aM12
									end
									lmn = lmn + 1
								end
							end
						end

					elsif aChoiceM == "M2"
						aMovie1 = File.exists?(macUsername + '/Desktop/Comp/Movie/Movie2/Movie2.txt')
						if aMovie1 == true
							File.open(macUsername + '/Desktop/Comp/Movie/Movie2/Movie2.txt') do |file|
								lines = Array.new
								file.each_line do |line|
									lines.push line
								end
								aM11 = lines[0].to_i
								aM12 = lines[1].to_i
								aM13 = lines[2].to_f
								lm = aM12
								lmn = 0
								while lm >= lmn
									system ("clear")
									if aM11 >= 1
										filename = macUsername + '/Desktop/Comp/Movie/Movie2/f1.txt'
										File.open filename, 'r' do |f|
											f1 = f.read
											puts f1
										end
										sleep aM13
									end
									system ("clear")
									if aM11 >= 2
										filename = macUsername + '/Desktop/Comp/Movie/Movie2/f2.txt'
										File.open filename, 'r' do |f|
											f2 = f.read
											puts f2
										end
										sleep aM13
									end
									system ("clear")
									if aM11 >= 3
										filename = macUsername + '/Desktop/Comp/Movie/Movie2/f3.txt'
										File.open filename, 'r' do |f|
											f3 = f.read
											puts f3
										end
										sleep aM13
									end
									system ("clear")
									if aM11 == 4
										filename = macUsername + '/Desktop/Comp/Movie/Movie2/f4.txt'
										File.open filename, 'r' do |f|
											f4 = f.read
											puts f4
										end
										sleep aM13
									end
									lmn = lmn + 1
								end
							end
						end
					elsif aChoiceM == "STOP"
						loopm = 0
					end
				end
				if aM == false
					FileUtils.mkdir(macUsername + '/Desktop/Comp/Movie')
					filename = "Movies.txt"
					File.open filename, 'w' do |f|
						f.write "example\n"
						FileUtils.mv(macUsername + '/Desktop/Movies.txt', macUsername + '/Desktop/Comp/Movie/Movies.txt')
					end

					puts "Please run Movie again"
					loopm = 0
				end

			end
		end

		if aChoice.upcase == "V"

			puts
			sleep 1.2
			puts "The"
			sleep 1.2
			puts "JC"
			sleep 1.2
			puts "Comp"
			sleep 1.2
			puts "V 1.0 Alpha"
			sleep 1.2
			puts "Made by:"
			sleep 1.2
			puts "Well..."
			sleep 1.2
			puts "...JC"
			sleep 1.2
			puts "Of course!"
			sleep 1.2
			puts
			puts "Version & Info"
			puts "JC Comp inc."
			puts "Version 1.0 Alpha"
			puts "OS version: Mac"
			puts "Press Enter to Continue"
			blah = gets.chomp
			puts
		end

		if aChoice.upcase == "B"
			file = File.exists?(macUsername + '/Desktop/Comp/Bday.txt')

			if file == true
				filename = macUsername + '/Desktop/Comp/Bday.txt'
				File.open filename, 'r' do |f|
					bday2 = f.read
					puts "Your Current Bday on this computer is: " + bday2
				end
			elsif file == false
				puts "You first have to set a birthday in Settings/Customize"
			else
				puts "	Comp - ERROR103: 'file' IS UNKNOWN"
				puts "	DEV: file = " + file + "\n"
			end
		end

		if aChoice.upcase == "S"

			loop2 = 1

			while loop2 == 1

				puts "Change your account name (AC), Change your password (P), Check for updates (U), Set your birthday (SetB), Clear (C), Back (B)"

				aChoice2 = gets.chomp.upcase

				if aChoice2 == "AC"
					puts "New Username:"
					aUser = gets.chomp

					puts "Welcome " + aUser

					FileUtils.rm(macUsername + '/Desktop/Comp/aUser.txt')

					filename = "aUser.txt"
					File.open filename, 'w' do |f|
						f.write aUser
					end
					FileUtils.mv(macUsername + '/Desktop/aUser.txt', macUsername + '/Desktop/Comp/aUser.txt')
				end

				if aChoice2 == "P"
					puts "Old Password:"
					password3 = STDIN.noecho(&:gets).chomp

					if password3 == password
						puts "New Password:"
						password4 = STDIN.noecho(&:gets).chomp

						system('chmod 755 ~/Desktop/Comp/Password')
						FileUtils.rm(macUsername + '/Desktop/Comp/Password/Password.txt')

						filename = "Password.txt"
						File.open filename, 'w' do |f|
							f.write password4
						end
						FileUtils.mv(macUsername + '/Desktop/Password.txt', macUsername + '/Desktop/Comp/Password/Password.txt')
						system('chmod 0 ~/Desktop/Comp/Password')
					else
						puts "Incorrect"
					end
				end

				if aChoice2 == "SETB"

					bday = File.exists?(macUsername + '/Desktop/Comp/Bday.txt')

					if bday == true
						filename = macUsername + '/Desktop/Comp/Bday.txt'
                        bdayLines = Array.new
						File.open filename, 'r' do |f|
    						f.each_line do |line|
    							bdayLines.push line
    						end
						end

						puts "Your Current Bday on this computer is: " + bdayLines[2]

						FileUtils.rm(macUsername + '/Desktop/Comp/Bday.txt')
                    end

					puts "Type the month"
					month = gets.chomp

					puts "Type the day"
					day = gets.chomp

					bday1 = month + "/" + day

					filename = "Bday.txt"
					File.open filename, 'w' do |f|
						f.write month + "\n" + day + "\n" + bday1
					end

					FileUtils.mv(macUsername + '/Desktop/Bday.txt', macUsername + '/Desktop/Comp/Bday.txt')
					puts "Your Current Bday on this computer is: " + bday1
				end

				if aChoice2 == "C"
					puts "Are you sure you want to clear? y/n"

					aChoice3 = gets.chomp

					if aChoice3 == "y"
						FileUtils.mv(macUsername + '/Desktop/Comp', macUsername + '/.Trash/Comp')
						puts "Sucsessfully cleared your comp."
						loop2 = 0
						loop = 0
					else
						puts "Did not respond with y, so did not clear"
					end
				end

				if aChoice2 == "B"
					puts "Loading..."
					sleep 0.1
					loop2 = 0
				end

				if aChoice2 == "E"
				m = File.exists?(macUsername + '/Desktop/Comp')
					if m == false
						puts "Are you sure you want to erase everything after 10 failed passcode attempts? y/n"
						Choice4 = gets.chomp
						if Choice4 == "y"
							filename = "Erase.txt"
							File.open filenme, 'w' do |f|
								f.write "1"
							end
							FileUtils.mv(macUsername + '/Desktop/Erase.txt', macUsername + '/Desktop/Comp/Erase.txt')
						end
					end
				end

				if aChoice2 == "U"
					$stdout = tee
					$stdout.puts 'Relaunched Logger Due to System Update...'

					puts "Checking..."
					$stdout = STDOUT
					system('curl -s -O https://dl.dropboxusercontent.com/s/15n9fze9y7p4ban/Version.txt?dl=1')
					$stdout = tee
					FileUtils.mv(macUsername + '/Desktop/Version.txt?dl=1', macUsername + '/Desktop/Comp/Version.txt')

					filename = macUsername + '/Desktop/Comp/Version.txt'
					File.open filename, 'r' do |f|
						lines = Array.new
						f.each_line do |line|
							lines.push line
						end

						VersionUpdated = lines[0].to_s

						filename = macUsername + '/Desktop/Comp.rb'
						File.open filename, 'r' do |f|
							lines = Array.new
							f.each_line do |line|
								lines.push line
							end
							VersionCurrent = lines[0].to_s

							VersionString1 = VersionCurrent.to_s.sub!('# Version = ', '').gsub("\n","")
							VersionString2 = VersionUpdated.to_s.sub!('# Version = ', '').gsub("\n","")

							puts 'Current Version is ' + VersionString1
							puts 'Updated Version is ' + VersionString2

							puts VersionString1.to_s
							puts VersionString2.to_s

							if VersionString1 == VersionString2
								puts "No Update Needed."
							else
								puts "Avalible Update, Installing now"
								sleep 2
								$stdout = STDOUT
								system('curl -O https://dl.dropboxusercontent.com/s/m3unfdh7v4qe17n/Comp.rb?dl=1')
								FileUtils.mv(macUsername + '/Desktop/Comp.rb', macUsername + '/Desktop/Comp/Versions/' + VersionString1 + '.rb')
								FileUtils.mv(macUsername + '/Desktop/Comp.rb?dl=1', macUsername + '/Desktop/Comp.rb')
								system('ruby Comp.rb')
								$stdout = tee
								loop2 = 0
								loop = 0
							end

							FileUtils.rm(macUsername + '/Desktop/Comp/Version.txt')
						end
					end

					$stdout = STDOUT
				end
			end
		end

		if aChoice.upcase == "T"
			TextFile = File.exists?(macUsername + '/Desktop/Comp/Text')
			if TextFile

			else
				FileUtils.mkdir(macUsername + '/Desktop/Comp/Text/')
			end
			allText = ""
			puts "Text Editor. Please type the name of the file"
			aFilename = gets.chomp
			looptext = 1
			while looptext == 1
				puts "Type words and hit enter. To type commands do '^' (Shift + 6), and type the letter for the command after (Do ^h for help)"
				puts allText
				currentText = gets.chomp

				cmd = currentText.include?("^")

				if cmd
					cmdLetter = currentText.sub("^", "")
					#Commands

					if cmdLetter == "s"
						File.open aFilename, 'w' do |f|
							f.truncate(0)
							f.write allText
							FileUtils.mv(macUsername + '/Desktop/' + aFilename, macUsername + '/Desktop/Comp/Text/' + aFilename)
						end
					end
					if cmdLetter == "c"
						puts "Do you want to save first?"
						aChoiceSave = gets.chomp.upcase
						if aChoiceSave == "Y"
							#Nothin'
						elsif aChoiceSave == "YES"
							#Nothin'
						else
							looptext = 0
						end
					end
					if cmdLetter == "h"
						puts "Do ^s to save, Do ^c to close (But Save First!)"
					end

				else
					allText = allText + currentText
				end
			end
		end

		if aChoice.upcase == "P"
			PluginAPI = File.exists?(macUsername + '/Desktop/Comp/API_2.0.rb')
			if PluginAPI
				system('ruby ' + macUsername + '/Desktop/Comp/API_2.0.rb /Desktop/Comp/Plugins/')
			else
				loopAPI = 1
				while loopAPI == 1
					puts "Plugin API not found. Use A to download automaticly or M once manually installed"
					aChoiceAPI = gets.chomp.upcase

					if aChoiceAPI == "A"
						system('curl -s -O https://dl.dropboxusercontent.com/s/5w989vhpg7skp06/API_2.0.rb?dl=1')
						FileUtils.mv(macUsername + '/Desktop/API_2.0.rb?dl=1', macUsername + '/Desktop/Comp/API_2.0.rb')
						loopAPI = 0
					elsif aChoiceAPI == "M"
						loopAPI = 0
					end

					system('ruby ' + macUsername + '/Desktop/Comp/API_2.0.rb')
				end
			end
		end

		if aChoice.upcase == "CL"
			puts "Clearing All Logs..."
			FileUtils.rm_rf(Dir.glob(macUsername + '/Desktop/Comp/logs/*'))
			sleep 0.5
		end

		if aChoice.upcase == "DEV"
			sleep 0.1

			if development == 1
				development = 0
				filename2 = "development.txt"
				File.open filename2, 'w' do |f|
					lines = Array.new
					f.each_line do |line|
						lines.push line
					end

					f.write "false" + "\n" + lines[1]
				end
				FileUtils.mv(macUsername + '/Desktop/development.txt', macUsername + '/Desktop/Comp/development.txt')
				puts "Development Mode has been deactivated..."
			else
				development = 1
				filename2 = "development.txt"
				File.open filename2, 'w' do |f|
					lines = Array.new
					f.each_line do |line|
						lines.push line
					end

					f.write "true" + "\n" + lines[1]
				end
				FileUtils.mv(macUsername + '/Desktop/development.txt', macUsername + '/Desktop/Comp/development.txt')
				puts "Development Mode has been activiated..."
			end

			sleep 0.1
		end

		if development == 1
			if aChoice.include?('system(') == true
				puts "System Message!"
				aChoice = aChoice.sub("system(", "")
				aChoice = aChoice.sub(")", "")
				puts "Message: " + aChoice
				system(aChoice)
			end
		end
	end
else
	puts "	Comp - ERROR101:CANT DEFINE MEMORY"
	puts "	DEV: doesIts = " + doesIts
	loop = 0
end

rescue
	log = tee.logReturn
	$stdout = tee
	puts "Error: " + $!.to_s
	$stdout = STDOUT

	if $!.to_s == "bad decrypt"
		system('ruby ~/Desktop/Comp.rb')
	end
end

end

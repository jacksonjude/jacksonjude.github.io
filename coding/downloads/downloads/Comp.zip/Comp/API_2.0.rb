require 'fileutils'
require 'etc'

pathToAPI = ARGV[0]
puts "API 2.0 Loaded"
sleep 0.1
user = File.expand_path("~")
puts "Welcome, " + Etc.getlogin
sleep 0.1

plugin = File.exists?(user + pathToAPI)
if plugin == false
    FileUtils.mkdir(user + pathToAPI)
    example = user + pathToAPI + "example.jcplugin"
    File.open example, 'w' do |f|
        f.write 'puts "Test456 Plugin Loaded"
puts "Test456 Plugin Unloaded"
Test456: Test1, Test2
test1
puts "This is the format for plugins, any one line ruby code can go here"
test2
puts "And this is how simple it is to make another line, and another, and another…"'
    end
end

puts "Scanning for plugins..."
path = user + pathToAPI + "*.jcplugin"

c = Array.new

d = Array.new

itemnum = 0

Dir.glob(path) do |item|
  next if item == '.' or item == '..' or item == ".DS_Store"
  c.push(item)
  c[itemnum].slice! user + pathToAPI
  itemnum = itemnum + 1
end
sleep 0.1

count = Dir[user + pathToAPI + "*.jcplugin"].length

z = count.to_s + " Plugins Found"
puts z
sleep 0.1
puts c
sleep 0.1

filtersActivated = Array.new
filterNames = Array.new
itemsInFilters = Array.new

c.each do |i|
	s = user + pathToAPI + i
	File.open s, 'r' do |f|
		lines = Array.new
		f.each_line do |line|
      		lines.push line

            if line.start_with?("|")
                filterNames = filterNames + [line.split(":")[0].sub!("|", "")]
                itemsInFilters = itemsInFilters + [line.split(":")[1].split(",")]
            end
    	end

		x = lines[0]
        if x.include?('puts')
            y = "\"[" + i + "] \""
            z = "puts " + y.to_s.sub!('.jcplugin', '') + "+"
            x.sub!('puts', z)
        end
		system('ruby -e \'' + x + "\'")
	end
end

loop = 1
while loop == 1
	puts "Type a Command"
	command = STDIN.gets.chomp

	if command.downcase == "help"
		puts "Type a command to run"
		puts "Commands:"
		puts "Default: Help, Settings (S), Shut Down (SD)"

		c.each do |i|
			s = user + pathToAPI + i
			File.open s, 'r' do |f|
				lines = Array.new
				f.each_line do |line|
					lines.push line
				end
				x = lines[2].to_s
				puts x
			end
		end
	elsif command.downcase == "sd"
		loop = 0
		c.each do |i|
			s = user + pathToAPI + i
			File.open s, 'r' do |f|
				lines = Array.new
				f.each_line do |line|
					lines.push line
				end
				x = lines[1].to_s
                if x.include?('puts')
                    y = "\"[" + i + "] \""
                    z = "puts " + y.to_s.sub!('.jcplugin', '') + "+"
                    x.sub!('puts', z)
                end
				system('ruby -e \'' + x + '\'')
			end
		end
		puts "API 2.0 Unloaded"
		puts "logout"
    elsif command.downcase == "s"
        loop2 = 1
        while loop2 == 1
            puts "Do you want to deactivate any plugins?"
            c.each do |i|
                puts i.to_s
            end
            puts "Activate (A)"
            puts "Back"
            str = STDIN.gets.chomp
            complete = 0
            c.each do |i|
                if str.downcase == i.downcase
                    d = d + [i]
                    c = c - [i]
                    complete = 1
                end
            end
            if str.downcase == "back"
                loop2 = 0
                complete = 1
            elsif str.downcase == "a"
                puts "Do you want to activate any plugins?"
                puts d
                puts "Back"
                str = STDIN.gets.chomp
                numberOn = 0
                d.each do |i|
                    if str.to_s == i.to_s
                        c = c + [i]
                        d = d - [i]
                        complete = 1
                    end
                    numberOn = numberOn + 1
                end
                if str.downcase == "back"
                    loop2 = 0
                    complete = 1
                end
            end
            if complete == 0
                puts "Command / Plugin not found"
            end
        end
    elsif command.downcase.start_with?("filter ")
        command = command.downcase.sub!("filter ", "")
        if command.downcase == "off"
            filtersActivated = []
        elsif command.downcase.start_with?("remove")
            filtersActivated = filtersActivated - [command.downcase.sub!("remove ", "")]
        else
            filtersActivated = filtersActivated + [command.downcase]
        end
	else
        timesLineRun = 0
		pluginsdone = 0
		complete = 0
        runOnce = 0
        words = Array.new
		c.each do |i|
			pluginsdone = pluginsdone + 1
            runOnce = 1
			s = user + pathToAPI + i
			File.open s, 'r' do |f|
				lines = Array.new
				f.each_line do |line|
					lines.push line
				end
				delete = [lines[0], lines[1]]
				lines2 = lines - delete
				line = 0
				lines2.each do |i|
					line = line + 1
                    if i.start_with?("|")
                        timesLineRun+=1
                    else
                        if timesLineRun.even?
                            if line.even?
                                words.push i
                            end
                        else
                            if line.odd?
                                words.push i
                            end
                        end
                    end
					if i.to_s.gsub(/\n+|\r+/, "\n").squeeze("\n").strip == command.downcase
						system('ruby -e\'' + lines2[line].gsub(/\n+|\r+/, "\n").squeeze("\n").strip.to_s + '\'')
						complete = 1
					else
						if lines2.count == line && complete == 0 && pluginsdone == c.count
							puts "Word not found"
							words.push('help', 'sd', 's')

							firstChar = command[0, 1]

							resultIncludes = Array.new
							resultBegins = Array.new
							words.each do |word|
								resultIncludes.push word.include?(command)
								resultBegins.push word.start_with?(firstChar)
							end

							notBeginWithResults = Array.new

							puts "Did you mean:\n"

							for i in (0..resultIncludes.size)
                                filterTestComplete = 0
                                if filtersActivated.count > 0
                                    for filter in filtersActivated
                                        if itemsInFilters[filterNames.index(filter)].include?(words[i])
                                            filterTestComplete = 1
                                            puts filterTestComplete
                                            puts "---------"
                                            puts itemsInFilters[filterNames.index(filter)]
                                            puts "---------"
                                        end
                                    end
                                else
                                    filterTestComplete = 1
                                end

                                if filterTestComplete
                                    if resultIncludes[i] == true
    									if resultBegins[i] == true
    										puts words[i]
    									else
    										notBeginWithResults.push(words[i])
    									end
    								end
                                end

                                filterTestComplete = 0
							end

							puts notBeginWithResults
						end
					end
				end
			end
		end
        if runOnce == 0 && command == ""
            puts "Word not found\nhelp\nsd\ns"
        end
	end
end
